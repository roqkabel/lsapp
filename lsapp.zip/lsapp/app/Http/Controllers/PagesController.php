<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PagesController extends Controller
{
    //Controller index Method

    public function index(){
        $title = 'Welcome To Laravel!';
        return view('page.index', compact('title'));
    }
    public function about(){
        $title = 'About Us';
        return view('page.about')->with('title' , $title);
    }
    public function services(){
        $data = array(
            'title' => 'Services',
            'services' => ['Web Development' , 'Programming' , 'SEO']
        );
        return view('page.services')->with($data);
    }
}
