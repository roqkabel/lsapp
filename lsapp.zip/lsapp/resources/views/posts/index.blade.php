@extends('layouts.app')

@section('content')
    <h1 class="display-4">Posts</h1>
    @if(count($posts) > 0)
        @foreach($posts as $post)
            <div class="alert alert-dark m-3">
            <div class="row">
            <div class="col-md-4 col-sm-4">
            @if($post->cover_image)
                <img src='/storage/cover_image/{{$post->cover_image}}' class="img-fluid img" alt="featured_image">
            @endif
            </div>
            <div class="col-md-8 col-sm-8">
                <h3><a href="/posts/{{$post->id}}">{{$post->title}}</a></h3>
                <small>{{$post->created_at}} by {{$post->user->name}}</small>
                @if(Auth::user()->id == $post->user_id)
                <form action="/delete/{{$post->id}}" method="get">
                <input type="submit" value="Delete" class="btn btn-danger pull-right">
                <!-- <form method="DELETE" hidden></form> -->
                </form>
                @endif
            </div>
            </div>


            </div>
        @endforeach
        {{$posts->links()}}
    @else
        <p>No post Found</p>
    @endif
@endsection
