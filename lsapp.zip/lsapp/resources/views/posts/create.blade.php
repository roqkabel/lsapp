@extends('layouts.app')
@section('content')
<div class="container">
<h1>Create Post</h1>
    <form action="/posts" method="post" enctype="multipart/form-data">
        <input type="text" name="title" placeholder='title' class="form-control"><br/>
        <textarea name="body" class="form-control" placeholder='Body'></textarea>
            <input type="file" name="cover_image" class="form-control">
        <button class="btn btn-primary btn-lg m-1" type="submit">Post</button>
    </form>
</div>

@endsection
