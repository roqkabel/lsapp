@extends('layouts.app')
@section('content')

            <div class="container">

<a class="btn btn-primary m-3" href="/posts">Back</a>
            @if($post->cover_image)
            <img src='/storage/cover_image/{{$post->cover_image}}' class="img-fluid img" alt="featured_image">
            @endif
                <h3>{{$post->title}}</h3>
                <p>{!!$post->body!!}</p>
                <hr>
                <small>{{$post->created_at}} by {{$post->user->name}}</small>
            </div>
            @if(!Auth::guest())
                @if(Auth::user()->id == $post->user_id)
                <a href="/posts/{{$post->id}}/edit" class="btn btn-info">Edit Post</a>

            <form action="/delete/{{$post->id}}" method="get">
                <input type="submit" value="Delete" class="btn btn-danger pull-right">
                <!-- <form method="DELETE" hidden></form> -->
            </form>
                @endif
            @endif

@endsection
