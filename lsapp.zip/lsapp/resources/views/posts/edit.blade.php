@extends('layouts.app')
@section('content')
<div class="container">
<h1>Edit Post</h1>
    <form action="/update/{{$post->id}}" method="post" enctype='multipart/form-data'>

    <input type="text" value="{{$post->title}}" name="title" placeholder='title' class="form-control shadow-none"><br/>

    <textarea name="body" rows='4' class="form-control shadow-none" placeholder='Body'>
    {{$post->body}}
    </textarea>
    <input type="file" name="cover_image" class="form-control">

    @if($post->cover_image)
            <img src='/storage/cover_image/{{$post->cover_image}}' class="img-fluid img" alt="featured_image">
            @endif
    <button class="btn btn-primary btn-lg m-1 shadow-none" type="submit">Update</button>
        <!-- <form method="PUT" hidden></form> -->
    </form>
</div>


@endsection
