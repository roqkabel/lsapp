<?php $__env->startSection('content'); ?>
<div class="container">
<h1>Edit Post</h1>
    <form action="/update/<?php echo e($post->id); ?>" method="post" enctype='multipart/form-data'>

    <input type="text" value="<?php echo e($post->title); ?>" name="title" placeholder='title' class="form-control shadow-none"><br/>

    <textarea name="body" rows='4' class="form-control shadow-none" placeholder='Body'>
    <?php echo e($post->body); ?>

    </textarea>
    <input type="file" name="cover_image" class="form-control">

    <?php if($post->cover_image): ?>
            <img src='/storage/cover_image/<?php echo e($post->cover_image); ?>' class="img-fluid img" alt="featured_image">
            <?php endif; ?>
    <button class="btn btn-primary btn-lg m-1 shadow-none" type="submit">Update</button>
        <!-- <form method="PUT" hidden></form> -->
    </form>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>