<?php $__env->startSection('content'); ?>
    <h1 class="display-4">Posts</h1>
    <?php if(count($posts) > 0): ?>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-dark m-3">
            <div class="row">
            <div class="col-md-4 col-sm-4">
            <?php if($post->cover_image): ?>
                <img src='/storage/cover_image/<?php echo e($post->cover_image); ?>' class="img-fluid img" alt="featured_image">
            <?php endif; ?>
            </div>
            <div class="col-md-8 col-sm-8">
                <h3><a href="/posts/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a></h3>
                <small><?php echo e($post->created_at); ?> by <?php echo e($post->user->name); ?></small>
                <?php if(Auth::user()->id == $post->user_id): ?>
                <form action="/delete/<?php echo e($post->id); ?>" method="get">
                <input type="submit" value="Delete" class="btn btn-danger pull-right">
                <!-- <form method="DELETE" hidden></form> -->
                </form>
                <?php endif; ?>
            </div>
            </div>


            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($posts->links()); ?>

    <?php else: ?>
        <p>No post Found</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>