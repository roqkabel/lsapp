<?php $__env->startSection('content'); ?>

            <div class="container">

<a class="btn btn-primary m-3" href="/posts">Back</a>
            <?php if($post->cover_image): ?>
            <img src='/storage/cover_image/<?php echo e($post->cover_image); ?>' class="img-fluid img" alt="featured_image">
            <?php endif; ?>
                <h3><?php echo e($post->title); ?></h3>
                <p><?php echo $post->body; ?></p>
                <hr>
                <small><?php echo e($post->created_at); ?> by <?php echo e($post->user->name); ?></small>
            </div>
            <?php if(!Auth::guest()): ?>
                <?php if(Auth::user()->id == $post->user_id): ?>
                <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-info">Edit Post</a>

            <form action="/delete/<?php echo e($post->id); ?>" method="get">
                <input type="submit" value="Delete" class="btn btn-danger pull-right">
                <!-- <form method="DELETE" hidden></form> -->
            </form>
                <?php endif; ?>
            <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>